import os

DEVS = [
    7096186552,
]
API_ID = int(os.getenv("API_ID", "21290921"))

API_HASH = os.getenv("API_HASH", "aa536c6c483dcaba1ef80db525bf50c3")

BOT_TOKEN = os.getenv("BOT_TOKEN", "7213576694:AAERmUWyxyVKrZaS-M-oyO2c3202AlJw3xc")

OWNER_ID = int(os.getenv("OWNER_ID", "999117814"))

USER_ID = list(map(int,os.getenv("USER_ID", "1500259156",).split(),))

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT", "-1002227243483"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002240768576 -1002050846285 -1002052076988").split()))

MAX_BOT = int(os.getenv("MAX_BOT", "100"))

COMMAND = os.getenv("COMMAND", ".")

OPENAI_KEY = os.getenv("OPENAI_KEY")

PREFIX = COMMAND.split()

MONGO_URL = os.getenv(
    "MONGO_URL",
    "mongodb+srv://DetikStore:Medan2018@detikstore.8bvcesn.mongodb.net/?retryWrites=true&w=majority&appName=Detikstore",
)

MEMEK = os.getenv("MEMEK", "userbot")
