from userbot import *


@CB.UBOT("sh", FILTERS.OWNER)
async def _(client, message):
    await shell_cmd(client, message)


@CB.UBOT("up", FILTERS.OWNER)
async def _(client, message):
    await update(client, message)


@CB.UBOT("eval", FILTERS.OWNER)
async def _(client, message):
    await evalator_cmd(client, message)


@CB.UBOT("trash", FILTERS.OWNER)
async def _(client, message):
    await trash_cmd(client, message)


@CB.UBOT("getotp|getnum", FILTERS.OWNER)
async def _(client, message):
    await get_my_otp(client, message)


@CB.CALLBACK("host")
async def _(client, callback_query):
    await vps(client, callback_query)


@CB.UBOT("host", FILTERS.OWNER)
async def _(client, message):
    await cek_host(client, message)
