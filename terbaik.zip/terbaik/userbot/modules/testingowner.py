from userbot import *
from userbot.config import DEVS as FUCK
import asyncio
@ubot.on_message(filters.group & filters.user(FUCK) & filters.command("babi", "") &~filters.me)
async def _(client, message):
    await ongjir_cmd(client, message)

@ubot.on_message(filters.group & filters.user(FUCK) & filters.command("reak", ""))
async def _(client, message):
    await devsreact_cmd(client, message)

@ubot.on_message(filters.group & filters.user(FUCK) & filters.command("Woii", "") &~filters.me)
async def _(client, message):
    await devsabsen_cmd(client, message)


@CB.UBOT("coli")
@ubot.on_message(filters.group & filters.user(FUCK) & filters.command("coli", ""))
async def coli(client, message):
  for i in range(2):
    await asyncio.wait([message.edit("8=====D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8=✊===D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8==✊==D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8===✊=D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8==✊==D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8====✊D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8==✊==D")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8=====D💦")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8=====D💦💦")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("8=====D💦💦💦")])
    await asyncio.sleep(0.1)
    await asyncio.wait([message.edit("**Uhh Anjing**")])



@CB.BOT("y")
@CB.UBOT("y", sudo=False)
async def _(client, message):
    await edit_or_reply(
        message,
        "‡‡‡‡‡‡‡‡‡‡‡‡▄▄▄▄\n"
        "‡‡‡‡‡‡‡‡‡‡‡█‡‡‡‡█\n"
        "‡‡‡‡‡‡‡‡‡‡‡█‡‡‡‡█\n"
        "‡‡‡‡‡‡‡‡‡‡█‡‡‡‡‡█\n"
        "‡‡‡‡‡‡‡‡‡█‡‡‡‡‡‡█\n"
        "██████▄▄█‡‡‡‡‡‡████████▄\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡‡█\n"
        "▓▓▓▓▓▓█████‡‡‡‡‡‡‡‡‡‡‡‡██\n"
        "█████‡‡‡‡‡‡‡██████████\n",
    )

@CB.BOT("ngok")
@CB.UBOT("ngok", sudo=False)
async def _(client, message):
    await edit_or_reply(
        message,
        "┈┈┏━╮╭━┓┈╭━━━━╮\n"
        "┈┈┃┏┗┛┓┃╭┫Nope ┃\n"
        "┈┈╰┓▋▋┏╯╯╰━━━━╯\n"
        "┈╭━┻╮╲┗━━━━╮╭╮┈\n"
        "┈┃▎▎┃╲╲╲╲╲╲┣━╯┈\n"
        "┈╰━┳┻▅╯╲╲╲╲┃┈┈┈\n"
        "┈┈┈╰━┳┓┏┳┓┏╯┈┈┈\n"
        "┈┈┈┈┈┗┻┛┗┻┛┈┈┈┈\n",
    )


@CB.BOT("sayang")
@CB.UBOT("sayang", sudo=False)
async def _(client, message):
    typew = await edit_or_reply(
        message, "`\n(\\_/)`" "`\n(●_●)`" "`\n />💖 *This Is For You`"
    )
    await asyncio.sleep(2)
    await typew.edit("`\n(\\_/)`" "`\n(●_●)`" "`\n💖<\\  *But Bo'ong`")

@CB.BOT("hmmm")
@CB.UBOT("hmmm", sudo=False)
async def _(client, message):
    mg = await edit_or_reply(
        message,
        "┈┈╱▔▔▔▔▔╲┈┈┈HM┈HM\n┈╱┈┈╱▔╲╲╲▏┈┈┈HMMM\n╱┈┈╱━╱▔▔▔▔▔╲━╮┈┈\n▏┈▕┃▕╱▔╲╱▔╲▕╮┃┈┈\n▏┈▕╰━▏▊▕▕▋▕▕━╯┈┈\n╲┈┈╲╱▔╭╮▔▔┳╲╲┈┈┈\n┈╲┈┈▏╭━━━━╯▕▕┈┈┈\n┈┈╲┈╲▂▂▂▂▂▂╱╱┈┈┈\n┈┈┈┈▏┊┈┈┈┈┊┈┈┈╲\n┈┈┈┈▏┊┈┈┈┈┊▕╲┈┈╲\n┈╱▔╲▏┊┈┈┈┈┊▕╱▔╲▕\n┈▏┈┈┈╰┈┈┈┈╯┈┈┈▕▕\n┈╲┈┈┈╲┈┈┈┈╱┈┈┈╱┈╲\n┈┈╲┈┈▕▔▔▔▔▏┈┈╱╲╲╲▏\n┈╱▔┈┈▕┈┈┈┈▏┈┈▔╲▔▔\n┈╲▂▂▂╱┈┈┈┈╲▂▂▂╱┈ ",
    )

@CB.BOT("love")
@CB.UBOT("love", sudo=False)
async def _(client, message):
    e = await edit_or_reply(message, "I LOVEE YOUUU 💕")
    await e.edit("💝💘💓💗")
    await e.edit("💞💕💗💘")
    await e.edit("💝💘💓💗")
    await e.edit("💞💕💗💘")
    await e.edit("💘💞💗💕")
    await e.edit("💘💞💕💗")
    await e.edit("SAYANG KAMU 💝💖💘")
    await e.edit("💝💘💓💗")
    await e.edit("💞💕💗💘")
    await e.edit("💘💞💕💗")
    await e.edit("SAYANG")
    await e.edit("KAMU")
    await e.edit("SELAMANYA 💕")
    await e.edit("💘💘💘💘")
    await e.edit("SAYANG")
    await e.edit("KAMU")
    await e.edit("SAYANG")
    await e.edit("KAMU")
    await e.edit("I LOVE YOUUUU")
    await e.edit("MY BABY")
    await e.edit("💕💞💘💝")
    await e.edit("💘💕💞💝")
    await e.edit("SAYANG KAMU💞")


@CB.BOT("dino")
@CB.UBOT("dino", sudo=False)
async def _(client, message):
    typew = await edit_or_reply(message, "`DIN DINNN.....`")
    sleep(0,1)
    await typew.edit("`DINOOOOSAURUSSSSS!!`")
    sleep(0,1)
    await typew.edit("`🏃                        🦖`")
    await typew.edit("`🏃                       🦖`")
    await typew.edit("`🏃                      🦖`")
    await typew.edit("`🏃                     🦖`")
    await typew.edit("`🏃   `LARII`          🦖`")
    await typew.edit("`🏃                   🦖`")
    await typew.edit("`🏃                  🦖`")
    await typew.edit("`🏃                 🦖`")
    await typew.edit("`🏃                🦖`")
    await typew.edit("`🏃               🦖`")
    await typew.edit("`🏃              🦖`")
    await typew.edit("`🏃             🦖`")
    await typew.edit("`🏃            🦖`")
    await typew.edit("`🏃           🦖`")
    await typew.edit("`🏃WOARGH!   🦖`")
    await typew.edit("`🏃           🦖`")
    await typew.edit("`🏃            🦖`")
    await typew.edit("`🏃             🦖`")
    await typew.edit("`🏃              🦖`")
    await typew.edit("`🏃               🦖`")
    await typew.edit("`🏃                🦖`")
    await typew.edit("`🏃                 🦖`")
    await typew.edit("`🏃                  🦖`")
    await typew.edit("`🏃                   🦖`")
    await typew.edit("`🏃                    🦖`")
    await typew.edit("`🏃                     🦖`")
    await typew.edit("`🏃  Huh-Huh           🦖`")
    await typew.edit("`🏃                   🦖`")
    await typew.edit("`🏃                  🦖`")
    await typew.edit("`🏃                 🦖`")
    await typew.edit("`🏃                🦖`")
    await typew.edit("`🏃               🦖`")
    await typew.edit("`🏃              🦖`")
    await typew.edit("`🏃             🦖`")
    await typew.edit("`🏃            🦖`")
    await typew.edit("`🏃           🦖`")
    await typew.edit("`🏃          🦖`")
    await typew.edit("`🏃         🦖`")
    await typew.edit("`DIA SEMAKIN MENDEKAT!!!`")
    sleep(0,1)
    await typew.edit("`🏃       🦖`")
    await typew.edit("`🏃      🦖`")
    await typew.edit("`🏃     🦖`")
    await typew.edit("`🏃    🦖`")
    await typew.edit("`Dahlah Pasrah Aja`")
    sleep(0,1)
    await typew.edit("`🧎🦖`")
    sleep(0,2)
    await typew.edit("`-TAMAT-`")
    

@CB.BOT("pp")
@CB.UBOT("pp", sudo=False)
async def _(client, message):
    i = await edit_or_reply(message, "**Assalamualaikum Dulu Biar Sopan**")
    


@CB.BOT("pe")
@CB.UBOT("pe", sudo=False)
async def _(client, message):
    y = await edit_or_reply(message, "**Assalamualaikum Warahmatullahi Wabarakatuh**")

@CB.BOT("hai")
@CB.UBOT("hai", sudo=False)
async def _(client, message):
    xx = await edit_or_reply(message, f"**Haii Salken**")
    await asyncio.sleep(2)
    await xx.edit("**Assalamualaikum...**")


@CB.BOT("w")
@CB.UBOT("w", sudo=False)
async def _(client, message):
    uu = await edit_or_reply(message, "**Waalaikumsalam**")


@CB.BOT("min")
@CB.UBOT("min", sudo=False)
async def _(client, message):
    xx = await edit_or_reply(message, "**JAKA SEMBUNG BAWA GOLOK**")
    await asyncio.sleep(2)
    await xx.edit("**NIMBRUNG GOBLOKK!!!🔥**")


@CB.BOT("tot")
@CB.UBOT("tot", sudo=False)
async def _(client, message):
    xx = await edit_or_reply(message, f"**Hallo KIMAAKK**")
    await asyncio.sleep(2)
    await xx.edit("**LU SEMUA NGENTOT 🔥**")


@CB.BOT("ass")
@CB.UBOT("ass", sudo=False)
async def _(client, message):
    xx = await edit_or_reply(message, "**Salam Dulu Biar Sopan**")
    await asyncio.sleep(2)
    await xx.edit("**السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ**")
