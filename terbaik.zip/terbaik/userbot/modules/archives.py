from userbot import *
from pyrogram.enums import ChatType
from asyncio import sleep

__MODULE__ = "archive"
__HELP__ = f"""
<b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀʀᴄʜɪᴠᴇ 』</b>

  <b>• ᴩᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ᴀʀᴄʜɪᴠᴇᴀʟʟ</code> ɢᴄ / ᴩᴠ
  <b>• ᴩᴇʙᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴩᴇsᴀɴ ᴩ
  <b>• ᴄᴏɴᴛᴏʜ : </b> <code>{PREFIX[0]}ᴀʀᴄʜɪᴠᴇᴀʟʟ</code> ɢᴄ

  <b>• ᴩᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ᴜɴᴀʀᴄʜɪᴠᴇᴀʟʟ</code> ɢᴄ / ᴩᴠ
  <b>• ᴩᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴜɴᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴩᴇsᴀɴ 
  <b>• ᴄᴏɴᴛᴏʜ : </b> <code>{PREFIX[0]}unarchiveall</code> ɢᴄ

  <b>• ᴩᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ᴀʀᴄʜɪᴠᴇ</code>
  <b>• ᴩᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴩᴇsᴀɴ ᴄʜᴀᴛ sᴀᴀᴛ ɪɴɪ

  <b>• ᴩᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ᴜɴᴀʀᴄʜɪᴠᴇ</code>
  <b>• ᴩᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴜɴᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴩᴇsᴀɴ ᴄʜᴀᴛ sᴀᴀᴛ ɪɴɪ

"""


cnt = "<emoji id=5211112665237175703>✅</emoji>"
ex = "<emoji id=5852812849780362931>❌</emoji>"
brs = "<emoji id=5210935111289159311>🔘</emoji>"


@CB.UBOT("archiveall", sudo=False)
async def _(client, message):
    done = 0
    gagal = 0
    rizal = await message.reply_text("<emoji id=6010111371251815589>⏳</emoji>ᴘʀᴏᴄᴄᴇsɪɴɢ....")

    if len(message.command) != 2:
        await rizal.edit(f"{ex} ɢᴜɴᴀᴋᴀɴ ᴛʏᴩᴇ ᴜsᴇʀ / ɢʀᴏᴜᴩ")
        return

    query = message.command[1]

    chat_ids = await get_data_id(client, query)

    for chat_id in chat_ids:
        await sleep(1)
        try:
            await client.archive_chats(chat_id)
            done += 1
        except:
            gagal += 1
            pass

    await rizal.edit(f"""{brs} **ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴀʟᴀɴᴋᴀɴ ᴀʀᴄʜɪᴠᴇ**
<blockquote>{cnt}**ʙᴇʀʜᴀsɪʟ** : {done} **ɢʀᴜᴘ**</blockquote>
<blockquote>{ex}**ɢᴀɢᴀʟ** : {gagal} **ɢʀᴜᴘ**</blockquote>
**ᴘᴏᴡᴇʀᴇᴅ ʙʏ : **<a href=tg://user?id={client.me.id}>{client.me.first_name} {client.me.last_name or ''}</a>""")


@CB.UBOT("unarchiveall", sudo=False)
async def _(client, message):
    done = 0
    gagal = 0
    rizal = await message.reply_text("<emoji id=6010111371251815589>⏳</emoji>ᴘʀᴏᴄᴄᴇsɪɴɢ....")

    if len(message.command) != 2:
        await rizal.edit(f"{ex} gunakan type users atau group")
        return

    query = message.command[1]

    chat_ids = await get_data_id(client, query)

    for chat_id in chat_ids:
        await sleep(1)
        try:
            await client.unarchive_chats(chat_id)
            done += 1
        except:
            gagal += 1
            pass

    await rizal.edit(f"""{brs} **ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴀʟᴀɴᴋᴀɴ ᴜɴᴀʀᴄʜɪᴠᴇ**
<blockquote>{cnt}**ʙᴇʀʜᴀsɪʟ** : {done} **ɢʀᴜᴘ**</blockquote>
<blockquote>{ex}**ɢᴀɢᴀʟ** : {gagal} **ɢʀᴜᴘ**</blockquote>
**ᴘᴏᴡᴇʀᴇᴅ ʙʏ : **<a href=tg://user?id={client.me.id}>{client.me.first_name} {client.me.last_name or ''}</a>""")


@CB.UBOT("archive", sudo=False)
async def _(client, message):
    user_id = message.chat.id
    c = await client.archive_chats(user_id)
    if c:
        await message.reply_text(f"{cnt} ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢ ᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴘᴇɴɢɢᴜɴᴀ..")
    else:
                await message.reply_text(f"{ex} ɢᴀɢᴀʟ ᴍᴇɴɢ ᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴘᴇɴɢɢᴜɴᴀ..")

@CB.UBOT("unarchive", sudo=False)
async def _(client, message):
    user_id = message.chat.id
    c = await client.archive_chats(user_id)
    if c:
        await message.reply_text(f"{cnt} ʙᴇʀʜᴀsɪʟ ᴍᴇɴɢᴜɴ ᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴘᴇɴɢɢᴜɴᴀ..")
    else:
                await message.reply_text(f"{ex} ɢᴀɢᴀʟ ᴍᴇɴɢ ᴀʀᴄʜɪᴠᴇᴋᴀɴ ᴘᴇɴɢɢᴜɴᴀ..")
