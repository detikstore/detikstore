from userbot import *
from pyrogram.enums import ChatType, ChatMemberStatus
from userbot.core.database.saved import get_chat


__MODULE__ = "new gcast"
__HELP__ = f"""
<b>『 bantuan untuk gcastnew 』</b>

  <b>• perintah:</b> <code>{PREFIX[0]}bc</code> ɢʀᴏᴜᴘ ʙᴀʟᴀꜱ ᴋᴇ ᴘᴇꜱᴀɴ
  <b>• penjelasan:</b> group[grup], admin[khusus admin], users[private chat]

"""

def get_message(message):
    msg = (
        message.reply_to_message
        if message.reply_to_message
        else ""
        if len(message.command) < 2
        else " ".join(message.command[1:])
    )
    return msg

cnt = "<emoji id=6114011655253790197>✅</emoji>"
ex = "<emoji id=6113891550788324241>❌</emoji>"

@CB.UBOT("bc", sudo=True)
async def _(c, m):
    done = 0
    gagal = 0
    if len(m.command) != 2:
        await m.reply(f"**<emoji id =5929358014627713883>❌</emoji> mohon gunakan format: bc [gc adm pv] **")
        return
    send = get_message(m)
    if not send:
        await m.reply(f"<emoji id=5911461474315802019>⭐</emoji> **mohon balas ke pesan** !", quote=True)
        return
    if not m.reply_to_message:
        await m.reply(f"<emoji id=5911461474315802019>⭐</emoji> **mohon balas ke pesan** !", quote=True)
        return
    blacklist = await get_chat(c.me.id)
    try:
        if m.command[1] == "group":
            Haku = await m.reply(f"<emoji id=5372917041193828849>🚀</emoji> **ꜱᴇᴅᴀɴɢ ᴍᴇɴʏᴇʙᴀʀ ɢᴄᴀꜱᴛ**...")
            async for dialog in c.get_dialogs():
                if dialog.chat.type in (ChatType.SUPERGROUP, ChatType.GROUP):
                    chat_id = dialog.chat.id
                    await asyncio.sleep(0.1)
                    if chat_id not in blacklist:
                        try:
                            await send.copy(chat_id)
                            done += 1
                        except Exception:
                            gagal += 1
                            pass

            await Haku.edit(f""" 
 **ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴀʟᴀɴᴋᴀɴ ʙʀᴏᴀᴅᴄᴀsᴛ**
<blockquote>{cnt}**ʙᴇʀʜᴀsɪʟ** : {done} **ɢʀᴏᴜᴘ**</blockquote>
<blockquote>{ex}**ɢᴀɢᴀʟ** : {gagal} **ɢʀᴏᴜᴘ**</blockquote>""")

        elif m.command[1] == "users":
            Haku = await m.reply(f"<emoji id=5372917041193828849>🚀</emoji> **ꜱᴇᴅᴀɴɢ ᴍᴇɴʏᴇʙᴀʀ ᴜᴄᴀꜱᴛ**...")
            async for dialog in c.get_dialogs():
                if dialog.chat.type == ChatType.PRIVATE:
                    chat_id = dialog.chat.id
                    await asyncio.sleep(0.1)
                    if chat_id not in blacklist:
                        try:
                            await send.copy(chat_id)
                            done += 1
                        except Exception:
                            pass

            await Haku.edit(f""" 
**ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴀʟᴀɴᴋᴀɴ ʙʀᴏᴀᴅᴄᴀsᴛ**
<blockquote>{cnt}**ʙᴇʀʜᴀsɪʟ** : {done} **ᴜꜱᴇʀꜱ**</blockquote>
<blockquote>{ex}**ɢᴀɢᴀʟ** : {gagal} **ᴜꜱᴇʀꜱ**</blockquote>""")

        elif m.command[1] == "admin":
            Haku = await m.reply(f"<emoji id=5372917041193828849>🚀</emoji> **ꜱᴇᴅᴀɴɢ ᴍᴇɴʏᴇʙᴀʀ ɢᴄᴀꜱᴛ ᴋᴇ ɢʀᴜᴘ ᴀᴅᴍɪɴ**...")
            async for dialog in c.get_dialogs():
                if dialog.chat.type in (ChatType.SUPERGROUP, ChatType.GROUP):
                    chat_id = dialog.chat.id
                    await asyncio.sleep(0.1)
                    try:
                        member = await c.get_chat_member(chat_id, "me")
                        if member.status in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.OWNER):
                            await send.copy(chat_id)
                            done += 1
                    except Exception:
                        pass
            await Haku.edit(f""" **ʙᴇʀʜᴀsɪʟ ᴍᴇɴᴊᴀʟᴀɴᴋᴀɴ ʙʀᴏᴀᴅᴄᴀsᴛ ᴋᴇ ᴀᴅᴍɪɴ ɢʀᴜᴘ**
{cnt}**ʙᴇʀʜᴀsɪʟ** : {done} **ɢʀᴏᴜᴘ ᴀᴅᴍɪɴ**
{ex}**ɢᴀɢᴀʟ** : {gagal} **ɢʀᴏᴜᴘ ᴀᴅᴍɪɴ**
      **ᴘᴏᴡᴇʀᴇᴅ ʙʏ** :  **ɢʀᴀᴛɪs ᴜsᴇʀʙᴏᴛ** """)

    except IndexError:
        await m.edit(f"<emoji id=6113891550788324241>❌</emoji>**ᴍᴏʜᴏɴ ʀᴇᴘʟʏ ᴘᴇꜱᴀɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴄ ɢʀᴏᴜᴘ/ᴀᴅᴍɪɴ/ᴜꜱᴇʀꜱ !**")
