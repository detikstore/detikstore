from userbot import *
from pyrogram.enums import ParseMode

__MODULE__ = "showid"
__HELP__ = f"""
<b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜱʜᴏᴡ ɪᴅ 』</b>

  <b>• ᴘᴇʀɪɴᴛᴀʜ :</b> <code>{PREFIX[0]}id</code>
  <b>• ᴘᴇɴᴊᴇʟᴀꜱᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇʟɪʜᴀᴛ ɪᴅ ᴅᴀʀɪ ᴜꜱᴇʀ | ɢʀᴏᴜᴘ | ᴄʜᴀɴɴᴇʟ

  <b>• ᴘᴇʀɪɴᴛᴀʜ :</b> <code>{PREFIX[0]}idm</code>
  <b>• ᴘᴇɴᴊᴇʟᴀꜱᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ɪᴅ ᴅᴀʀɪ ᴇᴍᴏᴊɪ ᴘʀᴇᴍɪᴜᴍ 

  <b>• ᴘᴇʀɪɴᴛᴀʜ :</b> <code>{PREFIX[0]}id</code> [ʀᴇᴘʟʏ ᴛᴏ ᴜꜱᴇʀ | ᴍᴇᴅɪᴀ]
  <b>• ᴘᴇɴᴊᴇʟᴀꜱᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ɪᴅ ᴅᴀʀɪ ᴜꜱᴇʀ | ᴍᴇᴅɪᴀ

  <b>• ᴘᴇʀɪɴᴛᴀʜ :</b> <code>{PREFIX[0]}id</code> [ᴜꜱᴇʀɴᴀᴍᴇ ᴜꜱᴇʀ | ɢʀᴏᴜᴘ | ᴄʜᴀɴɴᴇʟ]
  <b>• ᴘᴇɴᴊᴇʟᴀꜱᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴛᴀʜᴜɪ ɪᴅ ᴜꜱᴇʀ | ɢʀᴜᴘ | ᴄʜᴀɴɴᴇʟ ᴍᴇʟᴀʟᴜɪ ᴜꜱᴇʀɴᴀᴍᴇ
"""

@CB.UBOT("id", sudo=True)
async def _(client, message):
    await id_cmd(client, message)

@CB.UBOT("idm", sudo=True)
async def _(client, message):
    zeb = message.reply_to_message
    if not zeb:
        return await message.reply_text("<emoji id=6113872536968104754>❎</emoji> **ᴍᴏʜᴏɴ ʙᴀʟᴀꜱ ᴋᴇ ᴇᴍᴏᴊɪ**")
    try:
        emoji_text = zeb.text
        emoji_id = zeb.entities[0].custom_emoji_id
        await message.reply_text(f"`<emoji id={emoji_id}>{emoji_text}</emoji>`", parse_mode=ParseMode.MARKDOWN)
    except NoneType:
        await message.reply_text("<emoji id=6113872536968104754>❎</emoji> **ᴍᴏʜᴏɴ ʙᴀʟᴀꜱᴀ ᴋᴇ ᴇᴍᴏᴊɪ ᴘʀᴇᴍɪᴜᴍ**!")
