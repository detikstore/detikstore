from userbot import *

__MODULE__ = "sangmata"
__HELP__ = f"""
<b>『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ꜱᴀɴɢᴍᴀᴛᴀ 』</b>

  <b>• ᴘᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}sg</code> [ᴜꜱᴇʀ_ɪᴅ | ʀᴇᴘʟʏ ᴜꜱᴇʀ]
  <b>• ᴘᴇɴᴊᴇʟᴀꜱᴀɴ:</b> **ᴜɴᴛᴜᴋ ᴍᴇᴍᴇʀɪᴋꜱᴀ ʜɪꜱᴛᴏʀɪ ɴᴀᴍᴀ | ᴜꜱᴇʀɴᴀᴍᴇ**
"""


@CB.UBOT("sg", sudo=False)
async def _(client, message):
    await sg_cmd(client, message)
