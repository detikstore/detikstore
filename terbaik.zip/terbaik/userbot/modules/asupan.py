from userbot import *

__MODULE__ = "asupan"
__HELP__ = f"""
<b>『 ʙᴀɴᴛᴜɴ ᴜɴᴛᴜᴋ ᴀsᴜᴩᴀɴ 』</b>

  <b>• ᴩᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ᴀsᴜᴩᴀɴ</code>
  <b>• ᴩᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢɪʀɪᴍ ᴠɪᴅɪᴏ ᴀsᴜᴩᴀɴ ʀᴀɴᴅᴏᴍ

  <b>• ᴩᴇʀɪɴᴛᴀʜ:</b> <code>{PREFIX[0]}ᴀʏᴀɴɢ</code>
  <b>• ᴩᴇɴᴊᴇʟᴀsᴀɴ:</b> ᴜɴᴛᴜᴋ ᴍᴇɴɢɪʀɪᴍ ғᴏᴛᴏ ᴄᴇᴡᴇᴋ ʀᴀɴᴅᴏᴍ

  <b>• perintah:</b> <code>{PREFIX[0]}cowok</code>
  <b>• penjelasan:</b> untuk mengirim photo cowok random

  <b>• perintah:</b> <code>{PREFIX[0]}anime</code>
  <b>• penjelasan:</b> untuk mengirim photo anime random
  
  <b>• perintah:</b> <code>{PREFIX[0]}bokep</code>
  <b>• penjelasan:</b> untuk mencari video bokep

"""


@CB.UBOT("asupan", sudo=True)
async def _(client, message):
    await video_asupan(client, message)


@CB.UBOT("ayang", sudo=True)
async def _(client, message):
    await photo_cewek(client, message)


@CB.UBOT("cowok", sudo=True)
async def _(client, message):
    await photo_cowok(client, message)


@CB.UBOT("anime", sudo=True)
async def _(client, message):
    await photo_anime(client, message)


@CB.UBOT("bokep", sudo=True)
async def _(client, message):
    await video_bokep(client, message)
