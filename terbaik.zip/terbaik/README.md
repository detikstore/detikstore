screen -S ubot
git clone https://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@github.com/onlyzalll/terbaikubot
cd terbaikubot
pip3 install -r requirements.txt
bash start