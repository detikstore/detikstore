#!/bin/bash

# Membuat virtual environment
sudo apt install python3.10-venv

sudo python3 -m venv venv

# Mengaktifkan virtual environment
source venv/bin/activate

# Memastikan pip terbaru diinstal
sudo pip3 install --upgrade pip

# Menginstal dependencies dari requirements.txt
sudo pip3 install -r requirements.txt
